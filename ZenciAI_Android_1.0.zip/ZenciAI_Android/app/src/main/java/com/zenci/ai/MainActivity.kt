package com.zenci.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val http = OkHttpClient.Builder()
        .callTimeout(90, TimeUnit.SECONDS).build()
    private val history = JSONArray()
    private val prefs by lazy {
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            this, "zenci_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    private val askPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startListening() else setStatus("Mikrofon izni verilmedi.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        append("ZENCİ", "Selam reis! Ben Zenci. API anahtarını Ayarlar bölümünden ekleyince sohbet edebiliriz.")
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
            setBackgroundColor(0xFF081B2D.toInt())
        }
        val header = TextView(this).apply {
            text = "Z E N C İ   A I"
            textSize = 24f; gravity = Gravity.CENTER
            setTextColor(0xFF65DDE5.toInt())
        }
        status = TextView(this).apply {
            text = "Çevrimiçi asistan • Hazır"
            textSize = 12f; gravity = Gravity.CENTER
            setTextColor(0xFFB7C9D8.toInt()); setPadding(0, 8, 0, 12)
        }
        transcript = TextView(this).apply {
            textSize = 16f; setTextColor(0xFFEAF4FA.toInt())
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
            setBackgroundColor(0xFF102A40.toInt())
        }
        input = EditText(this).apply {
            hint = "Zenci'ye bir şey söyle..."
            setHintTextColor(0xFF9FB2C2.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
        }
        val send = Button(this).apply { text = "Gönder"; setOnClickListener { sendMessage() } }
        val mic = Button(this).apply { text = "🎙 Konuş"; setOnClickListener { requestMic() } }
        val settings = Button(this).apply { text = "API Ayarları"; setOnClickListener { apiSettings() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(send, LinearLayout.LayoutParams(0, -2, 1f))
            addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
        }
        base.addView(header)
        base.addView(status)
        base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        base.addView(input)
        base.addView(row)
        base.addView(settings)
        setContentView(base)
    }

    private fun apiSettings() {
        val field = EditText(this).apply {
            hint = "sk-... API anahtarın"
            setText(prefs.getString("api_key", "") ?: "")
        }
        AlertDialogBuilder.show(this, "OpenAI API anahtarı", field) {
            val key = field.text.toString().trim()
            if (key.isNotEmpty()) {
                prefs.edit().putString("api_key", key).apply()
                setStatus("API anahtarı bu cihazda şifreli saklandı.")
            }
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        append("SEN", text)
        val key = prefs.getString("api_key", null)
        if (key.isNullOrBlank()) {
            append("ZENCİ", "Önce API Ayarları'ndan OpenAI API anahtarını eklemen gerekiyor.")
            return
        }
        history.put(JSONObject().put("role", "user").put("content", text))
        setStatus("Zenci düşünüyor...")
        scope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { callResponsesApi(key, history) }
                history.put(JSONObject().put("role", "assistant").put("content", answer))
                while (history.length() > 20) history.remove(0)
                append("ZENCİ", answer)
                tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "zenci_reply")
                setStatus("Hazır")
            } catch (e: Exception) {
                append("SİSTEM", "Bağlantı hatası: ${e.message ?: "Bilinmeyen hata"}")
                setStatus("Bağlantı kurulamadı")
            }
        }
    }

    private fun callResponsesApi(key: String, messages: JSONArray): String {
        val instructions = """
            Senin adın Zenci. Kullanıcıyla Türkçe, samimi ve doğal konuş.
            Gereksiz uzatma yapma. Kullanıcıya reis/kardeş gibi rahat hitap edebilirsin.
            Telefon üzerinde işlem yaptığını iddia etme; yalnızca uygulamanın gerçekten sunduğu
            özellikleri yaptığını söyle. Tehlikeli veya izinsiz işlemleri gerçekleştirme.
        """.trimIndent()
        val inputItems = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            inputItems.put(JSONObject().put("role", m.getString("role"))
                .put("content", m.getString("content")))
        }
        val body = JSONObject()
            .put("model", "gpt-6-luna")
            .put("instructions", instructions)
            .put("input", inputItems)
            .put("max_output_tokens", 700)
        val request = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}: ${raw.take(300)}")
            val json = JSONObject(raw)
            val output = json.optJSONArray("output") ?: JSONArray()
            val parts = mutableListOf<String>()
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                if (item.optString("type") != "message") continue
                val content = item.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    if (part.optString("type") == "output_text") parts.add(part.optString("text"))
                }
            }
            return parts.joinToString("\n").ifBlank { "Bu sefer cevap oluşturamadım reis." }
        }
    }

    private fun requestMic() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Bu cihazda konuşma tanıma hizmeti bulunamadı."); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            askPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        startListening()
    }

    private fun startListening() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("Dinliyorum...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setStatus("Ses işleniyor...") }
            override fun onError(error: Int) { setStatus("Ses tanıma hatası ($error)") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) { input.setText(spoken); sendMessage() }
                setStatus("Hazır")
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Zenci seni dinliyor")
        }
        recognizer?.startListening(intent)
    }

    private fun append(who: String, text: String) {
        transcript.append("\n$who\n$text\n")
    }
    private fun setStatus(text: String) { status.text = text }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale("tr", "TR")
    }

    override fun onDestroy() {
        scope.cancel()
        recognizer?.destroy()
        tts.stop(); tts.shutdown()
        super.onDestroy()
    }
}

private object AlertDialogBuilder {
    fun show(activity: AppCompatActivity, title: String, view: View, save: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(activity)
            .setTitle(title).setMessage("OpenAI API anahtarı gerekir. ChatGPT Plus aboneliği API kullanımını içermez; API ayrı ücretlendirilir.")
            .setView(view)
            .setPositiveButton("Kaydet") { _, _ -> save() }
            .setNegativeButton("İptal", null).show()
    }
}
