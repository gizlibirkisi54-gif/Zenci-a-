# ZENCİ AI – Android başlangıç projesi

Bu, Nubia 8046 gibi Android 8.0+ cihazlar için hazırlanmış **kaynak kod projesidir**.
Bu teslim bir APK değildir; bu ortamda Android SDK/Gradle ile APK derlemesi ve gerçek cihaz testi yapılmadı.

## İçindekiler
- Türkçe yazılı sohbet
- Android konuşma tanıma (mikrofon düğmesiyle)
- Android Text-to-Speech ile sesli cevap
- Son 20 mesajlık geçici konuşma bağlamı
- API anahtarını Android Keystore tabanlı EncryptedSharedPreferences ile cihazda saklama

## Önemli: API ücreti
Uygulama OpenAI Responses API kullanır. ChatGPT Plus aboneliği API kullanımını kapsamaz; API ayrı faturalandırılır.
API anahtarı: https://platform.openai.com/api-keys
Kullanım/faturalandırma: https://platform.openai.com/settings/organization/billing

API anahtarını kimseyle paylaşma. Bu örnek kişisel prototiptir; üretim uygulamasında API anahtarını telefonda tutmak yerine kendi güvenli sunucu ara katmanında saklamak gerekir.

## Derleme
1. Bilgisayarda Android Studio kur.
2. Bu klasörü Android Studio ile aç.
3. Gradle senkronizasyonunu bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Oluşan APK'yı telefona aktar ve kur. Android, bilinmeyen kaynaklardan kuruluma izin isteyebilir.

## İlk kullanım
1. Uygulamayı aç.
2. API Ayarları'na girip kendi API anahtarını ekle.
3. Mesaj yazarak veya Konuş düğmesine basarak dene.
4. Mikrofon izni sorulursa izin ver.

## Şimdilik olmayanlar
- Arka planda sürekli uyandırma kelimesi dinleme
- Telefon ayarlarını otomatik değiştirme
- WhatsApp/arama/SMS gönderme
- Kamera ile canlı algılama
- Bulut senkronizasyonlu kalıcı hafıza

Bunlar sonraki sürümlerde Android izinleri ve güvenlik onaylarıyla eklenebilir.

## Model
Varsayılan model `gpt-6-luna` olarak ayarlanmıştır. Hesabında bu model erişilebilir değilse `MainActivity.kt` içindeki model adını API hesabında kullanılabilen bir modelle değiştir.
